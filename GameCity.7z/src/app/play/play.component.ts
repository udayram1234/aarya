import { Component, OnInit } from '@angular/core';
import { GameServiceService } from '../game-service.service';
import { Igame } from '../game-city/Igame';
import { FormGroup, FormControl } from '../../../node_modules/@angular/forms';

@Component({
  selector: 'app-play',
  templateUrl: './play.component.html',
  styleUrls: ['./play.component.css']
})
export class PlayComponent implements OnInit {

  skForm : FormGroup ;
  games:Igame[];
  balance:number=600;

 
  constructor(private service:GameServiceService) { }

 
  
  ngOnInit() 
  {
    this.service.getGames().subscribe(data=>this.games=data);
  }
  play(games:Igame){
    
    if(this.balance>games.gamePrice){
        
        this.balance=(this.balance-games.gamePrice);
        alert("Thank you for playing"+ " "+games.gameName+" and your remaining balance is"+" "+ this.balance)
        }
        else
        {
          alert("Thank you for playing"+ " "+games.gameName+" and we are unable to process your request due to insuffecient funds")
        }
      }
    
    }
    

