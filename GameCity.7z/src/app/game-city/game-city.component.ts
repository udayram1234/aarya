import { Component, OnInit } from '@angular/core';
import { GameServiceService } from '../game-service.service';
import { Igame } from './Igame';
import { FormGroup, FormControl, Validators } from '../../../node_modules/@angular/forms';


@Component({
  selector: 'app-game-city',
  templateUrl: './game-city.component.html',
  styleUrls: ['./game-city.component.css']
})
export class GameCityComponent implements OnInit {
  skForm : FormGroup ;
  games:Igame[];
 
  constructor(private service:GameServiceService) { }


  ngOnInit() 
  {
    this.skForm= new FormGroup
    (
      {
    name : new FormControl(null,[Validators.required,Validators.pattern("^[a-z]{3,15}")]),
    address : new FormControl(null,[Validators.required, Validators.pattern("^[a-z]{5,30}")]),   
    amount : new FormControl(null,[Validators.required,Validators.pattern("^[0-9]{1,4}")])   
      }
    );
  this.service.getGames().subscribe(data=>this.games=data);
  }

 
  }

